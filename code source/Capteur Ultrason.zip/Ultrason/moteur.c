#include <msp430.h>



// Initialisation des roues du robot + Ajout des Timer



void init (){
// Code d'initialisation de la roue A (!!!!!!!Roue Gauche!!!!!!)
P2DIR |= BIT2;
P2SEL |= BIT2;
P2SEL2 &= ~BIT2;
P2DIR |= BIT1;
P2OUT &= ~BIT1;
// Code d'initialisation de la roue B (!!!!!!!Roue Droite!!!!!!)
P2DIR |= BIT4;
P2SEL |= BIT4;
P2SEL2 &= ~BIT4;
P2DIR |= BIT5;
P2OUT &= ~BIT5;



// r�glage de la fr�quence d'horloge � 1MHz



DCOCTL = CALDCO_1MHZ;
BCSCTL1 = CALBC1_1MHZ;



// set TimerA-0 period at 1250Hz (1MHz/8/100)



TA1CTL = 0|(TASSEL_2 | ID_0);
TA1CTL |= MC_1;
TA1CCR0 = 100; // p�riode du signal



// Activation mode de sortie n�7 sur TA1.1



TA1CCTL1 |= OUTMOD_7;
TA1CCR1 = 0; // rapport cyclique de TA1.1



// Activation mode de sortie n�7 sur TA1.2



TA1CCTL2 |= OUTMOD_7;
TA1CCR2 = 0; // rapport cyclique de TA1.2
}



// faire avancer le robot
void avancer()
{
//vitesse des roues



TA1CCR1 = 70;
TA1CCR2 = 70;



// sens des moteurs
P2OUT |= BIT5; // moteur B � 1 permet d'avancer
P2OUT &=~ BIT1; // moteur A � 1 permet d'avancer
}



// faire reculer le robot
void reculer()
{
// vitesse des roues
TA1CCR1 = 70;
TA1CCR2 = 70;
// sens des moteurs
P2OUT |= BIT1; //moteur A � 1 permet de reculer
P2OUT &=~ BIT5; // moteur B � 0 permet de reculer
}



// faire tourner le robot � droite: les deux roues tournent en sens inverse
void pivoter_droite()
{
// vitesse des roues
TA1CCR1 = 70;
TA1CCR2 = 70;
// sens des moteurs
P2OUT &=~ BIT5; // moteur B � 0 permet de reculer
P2OUT &=~ BIT1; // moteur A � 0 permet d'avancer
}



// faire tourner le robot � gauche: les deux roues tournent en sens inverse
void pivoter_gauche()
{
// vitesse des roues
TA1CCR1 = 70;
TA1CCR2 = 70;
// sens des moteurs
P2OUT |= BIT5; // moteur B � 1 permet d'avancer
P2OUT |= BIT1; //moteur A � 1 permet de reculer
}




// faire pivoter le robot � gauche: la roue droite est immobile et la roue gauche tourne en avant
void tourner_gauche() //pivoter_gauche_avant + pivoter_droite_avant
{
// vitesse de la roue A
TA1CCR2 = 70;
TA1CCR1 = 0;
// sens des moteurs
P2OUT &=~ BIT1; //moteur A � 0 permet d'avancer
}



// faire pivoter le robot � droite: la roue gauche est immobile et la roue droite tourne en avant
void tourner_droite()
{
// vitesse de la roue B
TA1CCR2 = 0;
TA1CCR1 = 70;
// sens des moteurs
P2OUT |= BIT5; //moteur B � 1 permet d'avancer
}



//arr�ter le robot
void stop()
{
TA1CCR1 = 0; //Vitesse Roue Gauche
TA1CCR2 = 0; //Vitesse Roue Droite
}
