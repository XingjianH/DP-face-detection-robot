void init ();

void avancer();

void reculer();

void pivoter_droite();

void pivoter_gauche();

void tourner_gauche();

void tourner_droite();

void stop();

