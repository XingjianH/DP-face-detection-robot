//------------------------------------------------------------------------------
// DUAL-US Display 2 US sensors JYC-2022
//------------------------------------------------------------------------------

#include <msp430g2553.h> // specific part of msp430.h
#include <intrinsics.h> // interrupt, delay, power mode ...
#include <stdbool.h> // boolean definitions
#include "moteur.h"

unsigned int memo_capt1, memo_capt2;
unsigned int diff_capt1, diff_capt2;
unsigned int distance;

//-- Timer Interrupt Service Routine -------------------------------------------
#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer_ISR(void)
{
unsigned int capt;

 capt = TA0CCR0;
TA0CCTL0 ^= CM_3;

 diff_capt1 = capt - memo_capt1;
memo_capt1 = capt;
}

//-- Main ----------------------------------------------------------------------
void main(void)
{
WDTCTL = WDTPW | WDTHOLD; // stop watch-dog timer

 //Aff_Init();
init();
P1DIR = BIT0;
P1OUT &= ~BIT0;

 // set SMCLK (Sub Main Clock) to 1MHz
DCOCTL = CALDCO_1MHZ; BCSCTL1 = CALBC1_1MHZ;

 //.. Timer0 as signal measure ................................................
P1SEL |= BIT1; // set P1.1 as TimerA-0 capture CCI0A
P1SEL2 &= ~BIT1; // ...
P1DIR &= ~BIT1; // set P1.1 as TimerA-0 input

 // set TimerA-0 to count at 1MHz
TA0CTL = TASSEL_2 | ID_0 | MC_2 | 0;

 // set TimerA-0 as rise edge / CCI0A / Capture mode / Interrupt enable
TA0CCTL0 = CM_1 | CCIS_0 | CAP | CCIE;

 P2SEL &= ~BIT7; // set P2.7 as I/O
P2SEL2 &= ~BIT7;
P2DIR |= BIT7; // set P2.7 as output
P2OUT &= ~BIT7; // set P2.7 to false

 memo_capt1 = memo_capt2 = 0;
diff_capt1 = diff_capt2 = 0;

 //............................................................................
__enable_interrupt();

 while(true) // endless loop
{
unsigned int
distance = diff_capt1 / 58;
unsigned int i = 0;
//Aff_valeur(convert_Hex_Dec(diff_capt1 >> 8));

 P2OUT |= BIT7; // set P1.0 to false
__delay_cycles(1200); // delay 1ms
P2OUT &= ~BIT7; // set P1.0 to false
__delay_cycles(300000); // delay 250ms
if(diff_capt1 < 836){
for(i=0 ;i<60000;i++){
    reculer();
}
for(i=0 ;i<50000;i++){
                       tourner_droite();}
avancer();
P1OUT |= BIT0;
}
else if(diff_capt1 < 1672){
    for(i=0 ;i<50000;i++){
                           tourner_droite();}
    avancer();
    P1OUT |= BIT0;
}
else {
    avancer();
    P1OUT &= ~BIT0;
}


 }
}

//------------------------------------------------------------------------------
